function version(e) {
	window.location = e.value;
}
