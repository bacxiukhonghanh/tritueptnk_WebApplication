+++
title = "Hello World Recipe"
description = "Hello world recipe / example for Echo"
[menu.side]
  name = "Hello World"
  parent = "recipes"
  weight = 1
+++

## Hello World Recipe

### Server

`server.go`

{{< embed "hello-world/server.go" >}}

### Maintainers

- [vishr](https://github.com/vishr)

### [Source Code]({{< source "hello-world" >}})
