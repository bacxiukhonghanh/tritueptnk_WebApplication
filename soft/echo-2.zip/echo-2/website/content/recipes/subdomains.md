+++
title = "Subdomains Recipe"
description = "Subdomains recipe / example for Echo"
[menu.side]
  name = "Subdomains"
  parent = "recipes"
  weight = 10
+++

## Subdomains Recipe

`server.go`

{{< embed "subdomains/server.go" >}}

### Maintainers

- [axdg](https://github.com/axdg)
- [vishr](https://github.com/vishr)

### [Source Code]({{< source "subdomains" >}})
