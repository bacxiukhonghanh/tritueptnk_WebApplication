+++
title = "Support"
+++

## Support Echo Development

<p>
  <a href="https://patreon.com/labstack" target="_blank"><br>
    <img style="width: 120px;" src="https://s3.amazonaws.com/patreon_public_assets/toolbox/patreon.png"><br>
    <p>Support via Patreon (recurring pledge)</p>
  </a>
</p>

<p>
  <a href="https://paypal.me/labstack" target="_blank"><br>
    <img style="width: 120px;" src="https://www.paypalobjects.com/webstatic/mktg/Logo/pp-logo-200px.png"><br>
    <p>Donate via PayPal (one time)</p>
  </a>
</p>

Echo is an MIT licensed open source project and completely free to use. If you are
using Echo in your products/projects, please consider sponsoring Echo to ensure
it is actively developed and maintained.
