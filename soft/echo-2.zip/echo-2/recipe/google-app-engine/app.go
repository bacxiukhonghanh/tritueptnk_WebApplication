package main

// reference our echo instance and create it early
var e = createMux()
