# Go TODO

This is a simple todo web app written in Go and using the Echo Framework

Just run the folowing

```
go get github.com/labstack/echo
go get github.com/mattn/go-sqlite3
go run todo.go
```

Then point your browser to http://localhost:8000
